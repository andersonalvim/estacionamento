package com.example.spring.mongo.api.resource;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.spring.mongo.api.model.Placa;
import com.example.spring.mongo.api.repository.PlacaRepositorio;

@RestController
public class PlacaController {
	
	@Autowired
	private PlacaRepositorio repositorio;
	
	@PostMapping("/addPlaca")
	public String savePlaca(@RequestBody Placa placa) {
		repositorio.save(placa);
		return "Adicionado placa com o id: " +placa.getId();
	}
	
	@GetMapping("/findAllPlacas")
	public List<Placa> getPlacas(){
		return repositorio.findAll();
	}
	
	@GetMapping("/getPlaca/{id}")
	public Optional<Placa> getPlaca(@PathVariable int id){
		return repositorio.findById(id);
	}
	
	@DeleteMapping("/delete/{id}")
	public String deletePlaca(@PathVariable int id) {
		repositorio.deleteById(id);
		return "Placa deletada com o id "+id;
	}
}
