package com.example.spring.mongo.api.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.spring.mongo.api.model.Placa;

public interface PlacaRepositorio extends MongoRepository<Placa, Integer>{

}
