package com.example.spring.mongo.api.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString

@Document(collection = "Placa")
public class Placa {
	@Id
	private int id;
	private String placa;
	private boolean pagamento;
	private boolean saiu;
	
	public int getId() {
		// TODO Auto-generated method stub
		return id;
	}

	public String getPlaca() {
		return placa;
	}

	public boolean isPagamento() {
		return pagamento;
	}

	public boolean isSaiu() {
		return saiu;
	}
	

}
