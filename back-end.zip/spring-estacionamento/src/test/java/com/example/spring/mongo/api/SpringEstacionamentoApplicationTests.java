package com.example.spring.mongo.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringEstacionamentoApplicationTests {

	@Test
	void contextLoads() {
	}

}
